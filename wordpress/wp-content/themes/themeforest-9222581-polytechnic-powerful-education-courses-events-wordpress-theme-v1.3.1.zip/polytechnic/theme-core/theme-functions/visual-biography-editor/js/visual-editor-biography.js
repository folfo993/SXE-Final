(function($){ 
	// Remove the textarea before displaying visual editor
	$('#description').parents('tr').remove();
})(jQuery);