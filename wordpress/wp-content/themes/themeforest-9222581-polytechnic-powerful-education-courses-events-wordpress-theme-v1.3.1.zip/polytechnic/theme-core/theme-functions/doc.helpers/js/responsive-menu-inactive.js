jQuery(document).ready(function($) {

$( "tbody.menu-locations > tr.menu-locations-row:nth-child(4) .menu-location-menus" ).replaceWith( "<td class='doc_helper'><a href='themes.php?page=install-required-plugins'>Install</a> and <a href='plugins.php'>Activate</a> the <strong>Responsive Menu</strong> plugin <br/><br/>Then, assign the responsive menu location <strong><a href='admin.php?page=responsive-menu'>Here</a></strong><br/>Open the <strong>Look & Feel</strong> tab > <strong>Choose Menu To Responsify</strong>.</td>" );

});