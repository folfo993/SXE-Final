jQuery(document).ready(function($) {

$( "tbody.menu-locations > tr.menu-locations-row:nth-child(4) .menu-location-menus" ).replaceWith( "<td class='doc_helper'>Assign the mobile menu <strong><a href='admin.php?page=responsive-menu'>Here</a></strong><br/>Open the <strong>Look & Feel</strong> tab > <strong>Choose Menu To Responsify</strong>.</td>" );

});