<style type="text/css">
<?php /* Custom CSS Modifications from the Admin Panel */
global $theme_options;

 
?>
</style>