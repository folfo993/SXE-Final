Place your theme language files in this directory.

Please visit the following links to learn more about translating WordPress themes:

http://codex.wordpress.org/Translating_WordPress
http://codex.wordpress.org/Function_Reference/load_theme_textdomain

Currently, we are including un-official translations for this theme included in this folder. Note, though, that these are auto generated and provided as a curtousy - since I'm an English only speaker. If you have an official translation that you would like to offer, we are happy to include it and provide credit :)

Cheers!
Charlie